package com.hostel.hostelPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostelPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
